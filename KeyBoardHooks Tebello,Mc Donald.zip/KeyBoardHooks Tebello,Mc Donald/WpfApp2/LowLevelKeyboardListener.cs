﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Input;

namespace DesktopWPFAppLowLevelKeyboardHook
{
    public class LowLevelKeyboardListener
    {
        /* Keyboard input constants - doesn't change over the life of the program (compile-time value and is immutable) 
         * Virtual-Key Codes for Keyboard input
         */
        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;
        private const int WM_SYSKEYDOWN = 0x0104;

        /*Using fucntions out of the user32.dll e.g. ActivateKeyBoardLayout, GetKeyboardType, SetKeyboardState
         * Using functions out of the kernel32.dll e.g. Close Handle, ClosePrivateNameSpace
         * Signatures for fucntions from pinvoke.net 
         */
         
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
        //SetWindowsHookEx - install hook procedure to monitor the system for certain types of events (keyboard events in this program)

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);
        //UnhookWindowsHook - Removes a hook procedure installed in a hook chain by SetWindowsHookEx

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
        //CallNextHookEx - passes hook information to the next hook procedure in the current hook chain

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);
        //GetModuleHandle - Gets module handle for specified module and the module must have been loaded by the calling process
        public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        public event EventHandler<KeyPressedArgs> OnKeyPressed; //

        private LowLevelKeyboardProc _proc;
        private IntPtr _hookID = IntPtr.Zero;

        public LowLevelKeyboardListener()
        {
            _proc = HookCallback;
        }

        public void HookKeyboard()
        {
            _hookID = SetHook(_proc);
        }

        public void UnHookKeyboard()
        {
            UnhookWindowsHookEx(_hookID);
        }

        private IntPtr SetHook(LowLevelKeyboardProc proc)
        {
            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule)
            {
                return SetWindowsHookEx(WH_KEYBOARD_LL, proc, GetModuleHandle(curModule.ModuleName), 0);
            }
        }

        private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && wParam == (IntPtr)WM_KEYDOWN || wParam == (IntPtr)WM_SYSKEYDOWN)
            {
                int vkCode = Marshal.ReadInt32(lParam);

                if (OnKeyPressed != null) { OnKeyPressed(this, new KeyPressedArgs(KeyInterop.KeyFromVirtualKey(vkCode))); }
                /*KeyInterop - comes from the System.Windows.Input.KeyInterop namespace from references WindowsBase(included by default for a wpf application)
                 * used to utilise key from virtualkey method against (vkCode) returned from int vkCode = Marshal.ReadInt32(lParam); 
                 * provides static methods to convert between win32 Virtual-keys and the WFP System.Windows.Input.Keyenumeration
                 */

            }

            return CallNextHookEx(_hookID, nCode, wParam, lParam);
        }
    }

    //Argument class for event OnKeyPressed conating key enumeration specifying key values on keyboard (from namespace System.Windows.Input.Key)
    public class KeyPressedArgs : EventArgs
    {
       public Key KeyPressed { get; private set; } //packages code returned by keypressed from windows and fires off in event everytime key is pressed on keyboard

        public KeyPressedArgs(Key key)
        {
            KeyPressed = key;
        }
    }
}